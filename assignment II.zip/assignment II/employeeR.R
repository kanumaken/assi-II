# Load necessary library
library(utils)

# Define zip file path and extraction directory
zip_file <- "C:/Users/hp/Employee_Profile.zip"
extract_dir <- "C:/Users/hp/Employee_Profile"

# Unzip the file into the target folder
unzip(zip_file, exdir = extract_dir)
cat("Unzip successful!\n")

# List all CSV files in the unzipped folder
csv_files <- list.files(extract_dir, pattern = "\\.csv$", full.names = TRUE)

# Check if a CSV was found and display it
if (length(csv_files) > 0) {
  employee_data <- read.csv(csv_files[1])
  print(employee_data)
} else {
  cat("No CSV file found in the extracted folder.\n")
}
